# MashMachine AI (Android source project)

A small native Android prototype for automatic video segment remixing. It imports a user-selected video, detects video sync-frame/keyframe timestamps, shuffles/repeats segments, remuxes samples into a new MP4, and saves the result to `Movies/MashMachineAI`.

## Important limitations

- This is a first prototype, not the full speech-aware surreal editor requested.
- It reorders segments at keyframe boundaries and generally preserves encoded audio/video; it does not yet transcribe words, pitch-shift audio, reverse audio, or render advanced visual effects.
- It works best with short MP4 files using compatible H.264 video and AAC audio. Codec combinations vary by Android device.
- The rendering implementation is a prototype and requires device testing; media formats with unusual track layouts or long/high-bitrate segments may fail.
- This environment did not have the Android SDK, Gradle, or network access to download Android build dependencies, so an APK could not be compiled or tested here. Do not treat this source archive as an installable APK.

## Build

Open the project in Android Studio or an Android IDE that supports Gradle, with Android SDK platform 35 and a compatible JDK installed. Let Gradle download the Android Gradle Plugin, then build the `app` debug APK. The output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Use

1. Install the built APK on an Android phone.
2. Select a short MP4 video.
3. Choose output duration and remix style.
4. Tap **MAKE MY MASHUP**.
5. Find the output in `Movies/MashMachineAI`.
