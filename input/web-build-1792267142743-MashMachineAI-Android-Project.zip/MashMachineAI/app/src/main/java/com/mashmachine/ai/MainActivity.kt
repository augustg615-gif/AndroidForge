package com.mashmachine.ai

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import java.util.Random
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val pickVideoCode = 41
    private var sourceUri: Uri? = null
    private lateinit var selectedLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var makeButton: Button
    private lateinit var durationSpinner: Spinner
    private lateinit var chaosSpinner: Spinner
    private val executor = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(16, 16, 26)
    private val panel = Color.rgb(29, 27, 45)
    private val accent = Color.rgb(181, 140, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        val title = TextView(this).apply {
            text = "MASHMACHINE AI"
            textSize = 27f
            setTextColor(accent)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Turn ordinary footage into chaotic comedy remixes. Processing runs on your phone."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(18))
        })
        val importButton = button("SELECT VIDEO", accent)
        root.addView(importButton, fullWidth())
        importButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, pickVideoCode)
        }
        selectedLabel = TextView(this).apply {
            text = "No video selected"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(16))
        }
        root.addView(selectedLabel)
        root.addView(sectionLabel("OUTPUT DURATION"))
        durationSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("15 seconds", "30 seconds", "60 seconds", "90 seconds"))
        }
        root.addView(durationSpinner, fullWidth())
        root.addView(sectionLabel("REMIX STYLE"))
        chaosSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Pure Chaos", "Absurd Conversation", "Brainrot", "Dream Logic", "Random Remix"))
        }
        root.addView(chaosSpinner, fullWidth())
        root.addView(TextView(this).apply {
            text = "This first version makes a real randomized video remix by reordering short segments at keyframe boundaries. It preserves the original encoded audio/video. Speech-aware word rearrangement and advanced effects are not included yet."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(16), 0, dp(16))
        })
        makeButton = button("MAKE MY MASHUP", accent)
        root.addView(makeButton, fullWidth())
        makeButton.setOnClickListener { startRemix() }
        statusLabel = TextView(this).apply {
            text = "Ready"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(10))
        }
        root.addView(statusLabel)
        val note = TextView(this).apply {
            text = "Tip: short MP4 videos encoded with H.264 video and AAC audio are the most compatible. Remixing may fail if the source uses unsupported codecs or has no keyframes near useful cut points."
            textSize = 12f
            setTextColor(Color.GRAY)
        }
        root.addView(note)
        setContentView(scroll)
    }

    private fun sectionLabel(s: String) = TextView(this).apply {
        text = s; textSize = 12f; setTextColor(accent); setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(s: String, color: Int) = Button(this).apply {
        text = s; setTextColor(Color.BLACK); setBackgroundColor(color); textSize = 14f
    }

    private fun fullWidth() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Android but retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoCode && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                sourceUri = uri
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                selectedLabel.text = "Selected: ${uri.lastPathSegment ?: "video file"}"
                statusLabel.text = "Ready to remix"
            }
        }
    }

    private fun startRemix() {
        val uri = sourceUri
        if (uri == null) { toast("Select a video first"); return }
        val targetSeconds = listOf(15, 30, 60, 90)[durationSpinner.selectedItemPosition]
        val style = chaosSpinner.selectedItemPosition
        makeButton.isEnabled = false
        statusLabel.text = "Analyzing video…"
        executor.execute {
            try {
                val temp = File(cacheDir, "mashmachine_${System.currentTimeMillis()}.mp4")
                remix(uri, temp, targetSeconds, style) { message -> runOnUiThread { statusLabel.text = message } }
                runOnUiThread { statusLabel.text = "Saving MP4…" }
                val saved = saveToDownloads(temp)
                temp.delete()
                runOnUiThread {
                    statusLabel.text = if (saved != null) "Finished! Saved to Downloads/MashMachineAI" else "Render finished but saving failed. Check available storage."
                    makeButton.isEnabled = true
                    if (saved != null) toast("Mashup saved to Downloads")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusLabel.text = "Could not remix this video: ${e.message ?: "unsupported media format"}"
                    makeButton.isEnabled = true
                }
            }
        }
    }

    private data class Segment(val startUs: Long, val endUs: Long) { val durationUs get() = endUs - startUs }
    private data class Sample(val track: Int, val pts: Long, val flags: Int, val data: ByteArray)

    private fun remix(uri: Uri, output: File, requestedSeconds: Int, style: Int, progress: (String) -> Unit) {
        val extractor = MediaExtractor()
        extractor.setDataSource(this, uri, null)
        val formats = mutableListOf<MediaFormat>()
        val trackMap = mutableListOf<Int>()
        var videoTrack = -1
        var audioTrack = -1
        var durationUs = 0L
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") && videoTrack < 0) {
                videoTrack = i; formats.add(f); trackMap.add(i)
                if (f.containsKey(MediaFormat.KEY_DURATION)) durationUs = max(durationUs, f.getLong(MediaFormat.KEY_DURATION))
            } else if (mime.startsWith("audio/") && audioTrack < 0) {
                audioTrack = i; formats.add(f); trackMap.add(i)
                if (f.containsKey(MediaFormat.KEY_DURATION)) durationUs = max(durationUs, f.getLong(MediaFormat.KEY_DURATION))
            }
        }
        if (videoTrack < 0) { extractor.release(); throw IllegalArgumentException("No video track found") }
        val syncTimes = mutableListOf<Long>()
        extractor.selectTrack(videoTrack)
        while (true) {
            val t = extractor.sampleTime
            if (t < 0) break
            if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) syncTimes.add(t)
            extractor.advance()
        }
        extractor.release()
        if (syncTimes.size < 2) throw IllegalArgumentException("Not enough video keyframes to remix")
        if (durationUs <= 0L) durationUs = syncTimes.lastOrNull() ?: 0L
        val usableDuration = min(durationUs, requestedSeconds * 1_000_000L).coerceAtLeast(2_000_000L)
        val keyframes = syncTimes.filter { it < usableDuration }.toMutableList()
        if (keyframes.isEmpty() || keyframes.first() != 0L) keyframes.add(0, 0L)
        keyframes.add(usableDuration)
        keyframes.sort()
        val unique = keyframes.distinct()
        val segments = mutableListOf<Segment>()
        var i = 0
        while (i < unique.size - 1) {
            val start = unique[i]
            var j = i + 1
            while (j < unique.size - 1 && unique[j] - start < 2_000_000L) j++
            val end = unique[j]
            if (end - start >= 400_000L) segments.add(Segment(start, end))
            i = j
        }
        if (segments.size < 2) throw IllegalArgumentException("This video needs more keyframes. Try a longer MP4.")
        val seed = System.currentTimeMillis()
        val random = Random(seed)
        val order = segments.indices.toMutableList()
        // Distinct remix strategies: each has a different ordering pattern.
        when (style) {
            0 -> { order.shuffle(random); if (order.size > 3) { order.add(1, order[0]); order.add(order.size - 1, order[order.size - 2]) } }
            1 -> { order.sortBy { if (it % 2 == 0) it else -it }; order.shuffle(random) }
            2 -> { order.shuffle(random); if (order.size > 4) { val x = order[0]; order.add(1, x); order.add(2, x) } }
            3 -> { order.reverse(); if (order.size > 2) order.add(order.size / 2, order[0]) }
            else -> order.shuffle(random)
        }
        val maxOut = requestedSeconds * 1_000_000L
        val planned = mutableListOf<Segment>()
        var plannedDuration = 0L
        for (idx in order) {
            val seg = segments[idx]
            if (plannedDuration >= maxOut) break
            val take = min(seg.durationUs, maxOut - plannedDuration)
            if (take > 300_000L) { planned.add(Segment(seg.startUs, seg.startUs + take)); plannedDuration += take }
        }
        if (planned.isEmpty()) throw IllegalArgumentException("Could not create a valid edit plan")
        progress("Rendering ${planned.size} reordered segments…")
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outTracks = mutableMapOf<Int, Int>()
        for (srcTrack in trackMap) {
            val f = MediaExtractor().let { ex -> ex.setDataSource(this, uri, null); val fmt = ex.getTrackFormat(srcTrack); ex.release(); fmt }
            outTracks[srcTrack] = muxer.addTrack(f)
        }
        muxer.start()
        val allSamples = mutableListOf<Sample>()
        var outputBase = 0L
        val maxSamplesPerSegment = 25000
        for ((segIndex, seg) in planned.withIndex()) {
            progress("Processing segment ${segIndex + 1} of ${planned.size}…")
            val ex = MediaExtractor()
            ex.setDataSource(this, uri, null)
            for (track in trackMap) ex.selectTrack(track)
            ex.seekTo(seg.startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            var sampleCount = 0
            while (true) {
                val track = ex.sampleTrackIndex
                val pts = ex.sampleTime
                if (track < 0 || pts < 0 || pts >= seg.endUs) break
                if (pts >= seg.startUs && trackMap.contains(track)) {
                    val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
                    val size = ex.readSampleData(buffer, 0)
                    if (size > 0) {
                        val bytes = ByteArray(size); buffer.position(0); buffer.get(bytes, 0, size)
                        allSamples.add(Sample(track, outputBase + (pts - seg.startUs), ex.sampleFlags, bytes))
                        sampleCount++
                        if (sampleCount >= maxSamplesPerSegment) break
                    }
                }
                if (!ex.advance()) break
            }
            ex.release()
            outputBase += seg.durationUs
            // Write segment data in timestamp order to maintain sane interleaving.
            allSamples.sortBy { it.pts }
            for (sample in allSamples) {
                val b = ByteBuffer.wrap(sample.data)
                val info = MediaCodec.BufferInfo().apply { set(0, sample.data.size, sample.pts, sample.flags) }
                muxer.writeSampleData(outTracks[sample.track] ?: continue, b, info)
            }
            allSamples.clear()
        }
        muxer.stop(); muxer.release()
    }

    private fun saveToDownloads(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "MashMachine_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/MashMachineAI")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = contentResolver.insert(collection, values) ?: return null
        try {
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { input -> input.copyTo(out) } }
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null); throw e
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() { super.onDestroy(); executor.shutdownNow() }
}
